<h1>Контакты</h1>
<p>
telega: @nmbrsdntl<br/>
skypeid: nmbrs<br/>
email: nmbrsdntl@gmail.com<br/>
<br/>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1340.3152787753745!2d2.164124234391221!3d41.42672774022838!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12a49816718e30e5%3A0x44b0fb3d4f47660a!2z0JHQsNGA0YHQtdC70L7QvdCw!5e0!3m2!1sru!2ses!4v1679307125617!5m2!1sru!2ses" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</p>
